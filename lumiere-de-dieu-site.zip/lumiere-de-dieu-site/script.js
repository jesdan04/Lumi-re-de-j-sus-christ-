const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
menuToggle?.addEventListener("click", () => mainNav.classList.toggle("open"));

document.querySelectorAll("#mainNav a").forEach(link => {
  link.addEventListener("click", () => mainNav.classList.remove("open"));
});

const searchBtn = document.getElementById("searchBtn");
const searchInput = document.getElementById("searchInput");
const searchMessage = document.getElementById("searchMessage");
searchBtn?.addEventListener("click", () => {
  const term = searchInput.value.trim();
  searchMessage.textContent = term
    ? `Recherche locale : « ${term} ». La recherche connectée sera ajoutée avec la base de données.`
    : "Écris un mot-clé pour commencer.";
});

document.getElementById("newsletterForm")?.addEventListener("submit", (event) => {
  event.preventDefault();
  document.getElementById("newsletterMessage").textContent =
    "Merci ! L'inscription sera activée après la connexion à la base de données.";
});
