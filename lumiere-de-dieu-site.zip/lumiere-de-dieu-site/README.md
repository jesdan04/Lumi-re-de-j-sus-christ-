# Lumière de Dieu

Site web spirituel chrétien en français.

## Contenu

- `index.html` : structure de la page
- `style.css` : design et responsive mobile
- `script.js` : menu mobile et interactions simples

## Lancer le site

Ouvrir `index.html` dans un navigateur.

## Prochaine étape

Connecter le site à Supabase pour enregistrer les articles, les utilisateurs, les abonnements et les témoignages.
